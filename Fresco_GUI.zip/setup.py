# compile with " python setup.py build_ext --inplace"

from setuptools import setup
from Cython.Build import cythonize

setup(
    #ext_modules = cythonize("hello.pyx",annotate=True)
    #ext_modules = cythonize("fib.pyx",annotate=True)
    ext_modules = cythonize(["myutil.pyx",
                            "qt_myutil.pyx",
                           "reactions.pyx",
                           "qt_omp_dialog.pyx",
                           "qt_dialog_windows.pyx",
                           "run_fresco_v2.pyx",
                           "qt_DWBA.pyx"])
)
